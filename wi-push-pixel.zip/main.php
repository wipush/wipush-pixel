<?php
/*
Plugin Name: Wi Push Pixel
Version: 1.0.3
Plugin URI: https://wipush.net/wi-push-plugin-wordpress/
Author: wipush
Author URI: https://wipush.net/
Description: Easily add Wi Push Pixel to your WordPress site
Text Domain: wi-push-pixel
Domain Path: /languages
 */

if (!defined('ABSPATH')) {
    exit;
}
if (!class_exists('WI_PUSH_PIXEL')) {

    class WI_PUSH_PIXEL {

        var $plugin_version = '1.0.0';

        function __construct() {
            define('WI_PUSH_PIXEL_VERSION', $this->plugin_version);
            $this->plugin_includes();
        }

        function plugin_includes() {
            if (is_admin()) {
                add_filter('plugin_action_links', array($this, 'plugin_action_links'), 10, 2);
            }
            add_action('plugins_loaded', array($this, 'plugins_loaded_handler'));
            add_action('admin_init', array($this, 'settings_api_init'));
            add_action('admin_menu', array($this, 'add_options_menu'));
            add_action('wp_head', array($this, 'add_pixel_auto_key_code'));
        }

        function plugins_loaded_handler()
        {
            load_plugin_textdomain('wi-push-pixel', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/');
        }

        function plugin_url() {
            if ($this->plugin_url)
                return $this->plugin_url;
            return $this->plugin_url = plugins_url(basename(plugin_dir_path(__FILE__)), basename(__FILE__));
        }

        function plugin_action_links($links, $file) {
            if ($file == plugin_basename(dirname(__FILE__) . '/main.php')) {
                $links[] = '<a href="options-general.php?page=wi-push-pixel-settings">'.__('Settings', 'wi-push-pixel').'</a>';
            }
            return $links;
        }
        function add_options_menu() {
            if (is_admin()) {
                add_options_page(__('Wipush Pixel', 'wi-push-pixel'), __('Wipush Pixel', 'wi-push-pixel'), 'manage_options', 'wi-push-pixel-settings', array($this, 'options_page'));
            }
        }
        function sanitize($input)
        {
            $sanitized_input = array();
            if(isset($input['pixel_key'])){
                $sanitized_input['pixel_key'] = sanitize_text_field($input['pixel_key']);
            }
            return $sanitized_input;
        }
        function settings_api_init(){
            $args = array(
                'sanitize_callback' => array( $this, 'sanitize' )
            );
            register_setting( 'wipushpixelpage', 'wi_push_pixel_settings', $args );


            add_settings_section(
                    'wi_push_pixel_section',
                    __('General Settings', 'wi_push_pixel'),
                    array($this, 'wi_push_pixel_settings_section_callback'),
                    'wipushpixelpage'
            );

            add_settings_field(
                    'pixel_key',
                    __('Pixel Key', 'wi-push-pixel'),
                    array($this, 'pixel_key_render'),
                    'wipushpixelpage',
                    'wi_push_pixel_section'
            );
        }
        function pixel_key_render() {
            $options = get_option('wi_push_pixel_settings');
            ?>
            <input type='text' name='wi_push_pixel_settings[pixel_key]' value='<?php echo $options['pixel_key']; ?>'>
            <p class="description"><?php printf(__('Enter your Pixel Key (e.g %s).', 'wi_push_pixel'), 'vn818lf51s84tigaypma0v781tgxhkjw');?></p>
            <?php
        }


        function options_page() {
            $url = "https://wipush.net/docs/help-center/articles/1/installing-wipush-with-wordpress";
            $link_text = sprintf(wp_kses(__('Please visit the <a target="_blank" href="%s">Wipush Pixel</a> documentation page for full setup instructions.', 'wi-push-pixel'), array('a' => array('href' => array(), 'target' => array()))), esc_url($url));
            ?>
            <div class="wrap">
            <h2>Wi Push Pixel - v<?php echo $this->plugin_version; ?></h2>
            <div class="update-nag"><?php echo $link_text;?></div>
            <form action='options.php' method='post'>
            <?php
            settings_fields('wipushpixelpage');
            do_settings_sections('wipushpixelpage');
            submit_button();
            ?>
            </form>
            </div>
            <?php
        }

        function add_pixel_auto_key_code() {
            $options = get_option('wi_push_pixel_settings');
            $pixel_key = $options['pixel_key'];
            if(isset($pixel_key) && !empty($pixel_key)){
                $ouput = <<<EOT
                <!-- Pixel Code for https://wipush.net/ -->
                    <script async src="https://wipush.net/pixel/{$pixel_key}"></script>
                    <!-- END Pixel Code -->
EOT;

                echo $ouput;
            }
        }

    }

    $GLOBALS['wi_push_pixel'] = new WI_PUSH_PIXEL();
}

